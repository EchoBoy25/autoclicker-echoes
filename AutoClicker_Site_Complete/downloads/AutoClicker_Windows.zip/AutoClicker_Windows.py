
import tkinter as tk
import threading
import time
import pyautogui
import keyboard
import random

clicking = False
key_spamming = False
click_thread = None
key_thread = None
click_interval = 0.1
key_to_spam = "space"
key_interval = 0.2
click_count = 0

def auto_click():
    global clicking, click_count
    while clicking:
        pyautogui.click()
        click_count += 1
        time.sleep(click_interval + random.uniform(-0.01, 0.01))

def toggle_click():
    global clicking, click_thread
    if not clicking:
        clicking = True
        click_thread = threading.Thread(target=auto_click)
        click_thread.start()
    else:
        clicking = False

def auto_key():
    global key_spamming
    while key_spamming:
        pyautogui.press(key_to_spam)
        time.sleep(key_interval + random.uniform(-0.01, 0.01))

def toggle_key():
    global key_spamming, key_thread
    if not key_spamming:
        key_spamming = True
        key_thread = threading.Thread(target=auto_key)
        key_thread.start()
    else:
        key_spamming = False

def panic_stop():
    global clicking, key_spamming
    clicking = False
    key_spamming = False

root = tk.Tk()
root.title("Gamer's Auto-Clicker Suite")
root.geometry("300x200")

click_label = tk.Label(root, text=f"Clicks: {click_count}")
click_label.pack(pady=10)

cps_slider = tk.Scale(root, from_=1, to=20, label="Clicks Per Second", orient=tk.HORIZONTAL)
cps_slider.set(10)
cps_slider.pack()

def update_cps():
    global click_interval
    click_interval = 1 / cps_slider.get()
    root.after(500, update_cps)

def update_click_label():
    click_label.config(text=f"Clicks: {click_count}")
    root.after(500, update_click_label)

keyboard.add_hotkey("f8", toggle_click)
keyboard.add_hotkey("f9", toggle_key)
keyboard.add_hotkey("f12", panic_stop)

update_cps()
update_click_label()

root.mainloop()
